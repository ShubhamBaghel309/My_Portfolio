import { motion } from 'framer-motion';

export default function Navigation() {
  return (
    <nav className="fixed w-full z-50 bg-black/5 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <span className="text-2xl font-bold"></span>
          <div className="flex space-x-8">
            <a href="#about" className="text-sm hover:text-yellow-400 transition-colors">About</a>
            <a href="#experience" className="text-sm hover:text-yellow-400 transition-colors">Experience</a>
            <a href="#projects" className="text-sm hover:text-yellow-400 transition-colors">Projects</a>
          </div>
        </div>
      </div>
    </nav>
  );
}