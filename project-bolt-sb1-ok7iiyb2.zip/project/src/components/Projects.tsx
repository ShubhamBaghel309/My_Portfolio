import { motion } from 'framer-motion';
import ProjectCard from './ProjectCard';

const projects = [
  {
    title: "AI Resume Tailoring Tool",
    description: "Optimized resumes for ATS compatibility, boosting ATS scores by up to 30%, streamlining the process of generating tailored resumes and skill matching.",
    link: "https://github.com/ShubhamBaghel309/Resume_Tailor.git",
    technologies: ["Llama 3.3", "PyPDF2", "LangChain", "Streamlit"]
  },
  {
    title: "YouTube Video Summarizer",
    description: "Developed with Google Generative AI and YouTube Transcript API, offering various summary types and video history tracking, reducing review time by 70%.",
    link: "https://github.com/ShubhamBaghel309/Youtube-video-summarizer.git",
    technologies: ["Google Gen AI", "YouTube API", "Whisper", "Hugging Face"]
  },
  {
    title: "PDF Chat",
    description: "Chat with PDF documents using Llama 3.3 (70B) model via Groq API. Provides an intuitive interface for uploading PDFs and engaging in conversational Q&A.",
    link: "https://github.com/ShubhamBaghel309/PdfChat.git",
    technologies: ["Llama 3.3", "Groq API", "PDF Processing"]
  },
  {
    title: "Jarvis AI",
    description: "Voice-activated assistant built using Python. Performs tasks like web browsing, playing music, fetching weather information, and providing news updates.",
    link: "https://github.com/ShubhamBaghel309/Jarvis-AI.git",
    technologies: ["Python", "Google Gemini API", "Voice Recognition"]
  },
  {
    title: "AI Code Explainer",
    description: "An AI-powered application that provides detailed explanations of code snippets using LangChain and Llama 3.3 (via Groq Cloud).",
    link: "https://github.com/ShubhamBaghel309/AI-code-explainer-.git",
    technologies: ["LangChain", "Llama 3.3", "Groq Cloud"]
  },
  {
    title: "Cold Email Generator",
    description: "AI-powered tool designed to streamline the job application process by creating personalized and compelling cold emails tailored to specific job postings.",
    link: "https://github.com/ShubhamBaghel309/Cold-Email-Generator.git",
    technologies: ["NLP", "Web Scraping", "Semantic Search"]
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-[#111111] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-4xl font-bold mb-8">Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <ProjectCard {...project} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}