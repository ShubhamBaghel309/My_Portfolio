import { motion } from 'framer-motion';
import { GraduationCap, Award } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-[#111111] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-4xl font-bold mb-8">About Me</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                <GraduationCap className="text-yellow-400" />
                Education
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-medium">National Institute of Technology, Kurukshetra</h4>
                  <p className="text-gray-400">B-Tech: Artificial Intelligence and Machine Learning</p>
                  <p className="text-sm text-gray-500">2021 - Present</p>
                </div>
                <div>
                  <h4 className="text-lg font-medium">Rao Pahalad Singh School</h4>
                  <p className="text-gray-400">Class 12th (88.8%)</p>
                  <p className="text-sm text-gray-500">2019 - 2021</p>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                <Award className="text-yellow-400" />
                Skills & Certifications
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-medium">Technical Skills</h4>
                  <p className="text-gray-400">Python, SQL, C, TensorFlow, Keras, LangChain, Streamlit</p>
                </div>
                <div>
                  <h4 className="text-lg font-medium">Certifications</h4>
                  <ul className="text-gray-400 list-disc list-inside">
                    <li>Azure AI 900 - Azure Machine Learning</li>
                    <li>Supervised Machine Learning</li>
                    <li>Generative AI Beginner (Google Cloud)</li>
                    <li>Introduction to Large Language Models</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}