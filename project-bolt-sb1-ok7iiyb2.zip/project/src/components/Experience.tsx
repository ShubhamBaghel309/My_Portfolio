import { motion } from 'framer-motion';
import { Briefcase } from 'lucide-react';

const experiences = [
  {
    title: "Undergraduate Research Intern",
    company: "National Institute of Technology, Kurukshetra / ISRO",
    period: "Dec 2024 – Ongoing",
    location: "Haryana, India",
    achievements: [
      "Proposed jamming mitigation through jammed signal reconstruction using GANs.",
      "Preprocessed raw GNSS signal data into a structured format for analysis.",
      "Achieved 98% accuracy in GNSS jamming classification with VGG16 and ML models (SVM, LR,RF) using 10-fold cross-validation."
    ]
  },
  {
    title: "BCG GenAI Job Simulation",
    company: "Forage (Virtual Internship)",
    period: "Nov 2024",
    achievements: [
      "Developed an AI-powered chatbot for BCG's GenAI Consulting team, automating financial analysis from 10-K and 10-Q reports, improving turnaround time by 60%.",
      "Engineered rule-based logic for chatbot responses, enhancing data interpretation accuracy by 30%."
    ]
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-[#1A1A1A] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-4xl font-bold mb-8">Experience</h2>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <motion.div
                key={exp.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-[#111111] p-6 rounded-xl"
              >
                <div className="flex items-start gap-4">
                  <Briefcase className="w-6 h-6 text-yellow-400 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold">{exp.title}</h3>
                    <p className="text-yellow-400">{exp.company}</p>
                    <p className="text-gray-400 text-sm mb-4">{exp.period} {exp.location && `• ${exp.location}`}</p>
                    <ul className="list-disc list-inside text-gray-300 space-y-2">
                      {exp.achievements.map((achievement, i) => (
                        <li key={i}>{achievement}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}